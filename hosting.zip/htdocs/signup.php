<?php
$id = md5(rand(6000,PHP_INT_MAX));
?>
<?
include('geturl.php');
?>
<html>
<head>
<link href="data:image/x-icon;base64,AAABAAEAEBACAAAAAACwAAAAFgAAACgAAAAQAAAAIAAAAAEAAQAAAAAAQAAAAAAAAAAAAAAAAgAAAAAAAAAAAAAAHtRtAAAAAAAH4AAAD/AAABw4AAA4HAAAOBwAADgcAAA4HAAAOBwAADgcAAA4HAAAOBwAABw4AAAP8AAAB+AAAAAAAAD//wAA+B8AAPAPAADjxwAAx+MAAMfjAADH4wAAx+MAAMfjAADH4wAAx+MAAMfjAADjxwAA8A8AAPgfAAD//wAA" rel="icon" type="image/x-icon">
<Title>Free Hosting</Title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<style>
    table {
      letter-spacing: 1px;
      font-size: 0.9rem;
      border: 1px solid #f1f1fc;
      border-collapse: separate;
      border-spacing: 0;
    }

    td {
  border: solid 1px #fcfcfc;
  border-style: none solid solid none;
  padding: 10px;
    }
    th {
    background-color: #f1f1fc;
    border: 1px solid #f1f1fc;
      padding: 10px 20px;
    }
tr:first-child td:first-child { border-top-left-radius: 10px; }
tr:first-child td:last-child { border-top-right-radius: 10px; }

tr:last-child td:first-child { border-bottom-left-radius: 10px; }
tr:last-child td:last-child { border-bottom-right-radius: 10px; }

tr:first-child td { border-top-style: solid; }
tr td:first-child { border-left-style: solid; }
input[type=text] {
  background-color: #efefef;
  border-radius: 5px 5px 5px 5px;
  color: black;
  border: 1px solid gray;
  padding: 5px 5px;
}
input[type=password] {
  background-color: #efefef;
  border-radius: 5px 5px 5px 5px;
  color: black;
  border: 1px solid gray;
  padding: 5px 5px;
}
input[type=submit] {
box-shadow: 1px 1px 1px 1px #efefef;
  background-color: #e1e1e1;
  border-radius: 15px 15px 15px 15px;
  color: black;
  border: 1px solid #cfcfcf;
  padding: 5px 5px;
}

button {
box-shadow: 1px 1px 1px 1px #efefef;
  background-color: #f0f0f0;
  border-radius: 15px 15px 15px 15px;
  color: black;
  border: 1px solid #cfcfcf;
  padding: 5px 5px;margin: 5px 5px;
}
a:hover {
display: inline-block;
  background-color: white;
  color: black;
  border: 1px solid black;
  text-decoration:none;
}
a {
display: inline-block;
box-shadow: 1px 1px 1px 1px #f1f1f1;
  background-color: #f1f1f1;
  border-radius: 5px 5px 5px 5px;
  color: black;
  border: 1px solid #efefef;
  text-decoration:none;
  padding: 5px 5px 5px 5px;
  margin: 5px 5px 5px 5px;
}
.link {
display: inline-block;
box-shadow: 1px 1px 1px 1px #efefef;
  background-color: #efefef;
  border-radius: 15px 15px 15px 15px;
  color: black;
  border: 1px solid #cfcfcf;
  text-decoration:none;
  padding: 5px 5px 5px 5px;
  margin: 5px 5px 5px 5px;
}
</style>
</head>
<body>
<table border="1" style="width:100%;height:auto;"><tr>
<th><a class="link" href="https://www.net2ftp.com/index.php"><img style='text-align: center;' src='img/ftp.svg'> FTP Client</a></th><th><a class="link" href="https://db4free.net"><img style='text-align: center;' src='img/sql.svg'> SQL Server</a></th>
</tr></table>
<table border="1" style="width:100%;height:auto;"><tr>
<td align="right">Client area <a class="link" href="http://cpanel.<?echo $yourdomain;?>"><img style='text-align: center;' src='img/login.svg'> Log In</a></td>
</tr></table>
<form method=post action="http://order.<?echo $yourdomain;?>/register2.php">
<table border='1' style='width:100%;height:auto;'><tr><th><big>Enter subdomain name</big></th></tr>
<td align='center'>
<input style='width:100%;' placeholder="Enter subdomain" type=text name=username value="<? $subdomain = $_GET['subdomain']; echo $subdomain;?>" pattern="[a-z0-9]{4,16}" maxlength="16" oninvalid="this.setCustomValidity('Enter subdomain')" oninput="setCustomValidity('')" required></td>
</tr></table><table border='1' style='width:100%;height:auto;'><tr><th><img style='text-align: center;' src='img/pass.svg'> Password <font color=red>*</font></th><th><img style='text-align: center;' src='img/email.svg'> E-mail <font color=red>*</font></th></tr><td align='center'>
<input style='width:100%;' placeholder="Enter password" type=password name=password pattern=".{6,16}" maxlength="16" oninvalid="this.setCustomValidity('Enter password')" oninput="setCustomValidity('')" required></td><td align='center'>
<input style='width:100%;' placeholder="Enter e-mail address" type=text name=email pattern="[^@\s]+@[^@\s]+\.[^@\s]+" value="" oninvalid="this.setCustomValidity('Enter e-mail address')" oninput="setCustomValidity('')" required></td></tr></table>
<input type=hidden name=id value="<?PHP echo $id; ?>">
<table border='1' style='width:100%;height:auto;'><tr><th><img style='text-align: center;' src="http://order.<? echo $yourdomain;?>/image.php?id=<?PHP echo $id; ?>"></th></tr><tr><td align='center'>
<input style='width:100%;' placeholder="Enter security code" type=text pattern=".{5,5}" name=number oninvalid="this.setCustomValidity('Enter security code')" oninput="setCustomValidity('')" required></td></tr></table>
<table border='1' style='width:100%;height:auto;'><tr><td align='center'><button style='width:100%;' type="submit">Sign Up</button></td></form>
</tr></table>
<table border="1" align="center" style="width:100%;height:auto;"><tr>
<th align="left"><?php include 'stat.php'; ?></th>
<th align="right">&copy; 2024</th>
</tr></table>
</body>
</html>

